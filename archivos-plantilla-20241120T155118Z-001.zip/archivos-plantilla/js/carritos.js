// VARIABLES GLOBALES
const d = document;
let btnProducts = d.querySelectorAll(".btn-product");
let contadorCarrito = d.querySelector(".contar-pro");
let listadoCarrito = d.querySelector(".list-cart tbody");
let con = localStorage.getItem("contadorCarrito") ? parseInt(localStorage.getItem("contadorCarrito")) : 0;  // Recuperamos el contador desde localStorage, si existe

document.addEventListener("DOMContentLoaded", () => {
    cargarProLocalStorage();
    contadorCarrito.textContent = con;  // Actualizamos el contador con el valor recuperado
})

// RECORRER LOS BOTONES DE LOS PRODUCTOS
btnProducts.forEach((btn, i) => {
    btn.addEventListener("click", () => {
        con++; // Aumentar la variable
        contadorCarrito.textContent = con;
        localStorage.setItem("contadorCarrito", con);  // Guardamos el contador en localStorage
        infoProducto(i); 
    });
});

// FUNCION PARA AGREGAR PRODUCTOS AL CARRITO
function agregarProducto(producto) {
    let fila = d.createElement("tr");
    fila.setAttribute("data-id", con); 
    fila.innerHTML =
        `<td>${con}</td>
        <td><img src="${producto.imagen}" width="80px"></td>
        <td>${producto.nombre}</td>
        <td> $${producto.precio}</td>
        <td><span onclick="borrarProducto(this)" class="btn btn-danger">X</span></td>`;
    listadoCarrito.appendChild(fila);
    actualizarNumerosFila();  // Llamamos a la función para actualizar los números de las filas
}

// FUNCION PARA EXTRAER INFORMACION DEL PRODUCTO
function infoProducto(pos) {
    let producto = btnProducts[pos].parentElement.parentElement.parentElement;
    let info = {
        nombre: producto.querySelector("h3").textContent,
        precio: producto.querySelector("h5").textContent.split("$")[1],
        imagen: producto.querySelector("img").src,
        cantidad: 1
    };
    agregarProducto(info);
    guardarProLocalStorage(info);
}

// FUNCIÓN PARA QUITAR UN PRODUCTO DEL CARRITO
function borrarProducto(boton) {
    let fila = boton.parentElement.parentElement;
    // Se obtiene el id de la fila para saber qué producto borrar
    let idFila = fila.querySelector("td").textContent;

    // Eliminar la fila del carrito
    fila.remove();

    con--;
    contadorCarrito.textContent = con;

    // Actualizamos los números de las filas
    actualizarNumerosFila();

    // Actualizamos el contador en localStorage al eliminar un producto
    localStorage.setItem("contadorCarrito", con);
    eliminarProLocalStorage(idFila);
}

// GUARDAR LOS PRODUCTOS EN LOCALSTORAGE
function guardarProLocalStorage(producto) {
    let todosProductos = [];
    let productosPrevios = JSON.parse(localStorage.getItem("pro-carrito"));
    if (productosPrevios != null) {
        todosProductos = productosPrevios;
    }
    todosProductos.push(producto);
    localStorage.setItem("pro-carrito", JSON.stringify(todosProductos));
}

// ELIMINAR PRODUCTOS DEL LOCALSTORAGE
function eliminarProLocalStorage(idFila) {
    let productosPrevios = JSON.parse(localStorage.getItem("pro-carrito"));
    if (productosPrevios != null) {
        productosPrevios.splice(idFila - 1, 1);
        localStorage.setItem("pro-carrito", JSON.stringify(productosPrevios));
    }
}

// CARGAR PRODUCTOS DE LOCALSTORAGE EN EL CARRITO
function cargarProLocalStorage() {
    let todosProductos = [];
    let productosPrevios = JSON.parse(localStorage.getItem("pro-carrito"));
    if (productosPrevios != null) {
        todosProductos = productosPrevios;
    }

    todosProductos.forEach((producto, i) => {
        agregarProducto(producto);
    })

    // Después de agregar los productos, actualizamos los números de las filas
    actualizarNumerosFila();
}

// FUNCION PARA ACTUALIZAR LOS NÚMEROS DE LAS FILAS
function actualizarNumerosFila() {
    let filas = listadoCarrito.querySelectorAll("tr");
    filas.forEach((fila, index) => {
        fila.querySelector("td").textContent = index + 1;  // Reorganizamos el número en la columna "#"
    });
}

contadorCarrito.parentElement.addEventListener("click" ,()=>{
    listadoCarrito.parentElement.classList.toggle("ocultar");
});
